package master.localization;

public interface Localizer {

	public void localize();
	public double getFilteredData();
	
}
